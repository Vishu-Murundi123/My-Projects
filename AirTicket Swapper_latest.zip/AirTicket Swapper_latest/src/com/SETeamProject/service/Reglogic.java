package com.SETeamProject.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.SETeamProject.dao.Regdata;

public class Reglogic {
	public static Boolean regvalid(String firstname, String lastname, String email, String password, String confirm_password, String phone_no) throws SQLException
	{
        Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b");
        Matcher matcher = pattern.matcher(email);
        
		
		if(firstname.isEmpty())
		{
			return false;
		}
		else if(lastname.isEmpty())
		{
			return false;
		}
		else if(email.isEmpty() || !matcher.matches())
		{
			
			return false;
		}
		
		else if(password.isEmpty() || !password.equals(confirm_password))
		{
			return false;
		}
		
		else if(phone_no.isEmpty())
		{
			return false;
		}
		else 
		{
			Boolean val= Regdata.register(firstname, lastname,email, password, phone_no);
			return val;
		}
					
				
	}

}

package com.SETeamProject.service;

import java.sql.SQLException;

import com.SETeamProject.dao.Logindata;


public class Loginlogic {
	
		public static int logvalid(String email, String password) throws SQLException
		{
			
			if(email.isEmpty())
			{
				
				return 0;
			}
			else if(password.isEmpty())
			{
				
				return 0;
			}
			else 
			{
				int info = Logindata.signin(email, password);
				return info;
			}
						
					
		}
	}




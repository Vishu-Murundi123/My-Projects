package com.SETeamProject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Regdata {
	public static Boolean register(String firstname, String lastname, String email, String password,  String phone_no) throws SQLException {
		String address = null;
		PreparedStatement stmt  = getjdbcConnection().prepareStatement("select * from registration");
		ResultSet rs = stmt.executeQuery();
		int number = 1;
		while(rs.next()){
			number++;
		}
		stmt.close();
		PreparedStatement stmt2 = getjdbcConnection().prepareStatement("INSERT INTO registration(id,firstname,lastname,email,password,phone_no,address) values(?,?,?,?,?,?,?)");
		stmt2.setInt(1, number);
		stmt2.setString(2, firstname);
		stmt2.setString(3, lastname);
		stmt2.setString(4, email);
		stmt2.setString(5, password);
		stmt2.setString(6, phone_no);
		stmt2.setString(7, address);
		stmt2.executeUpdate();
		stmt2.close();
		return true;
	}

	static Connection connect=null;
	private static Connection getjdbcConnection() throws SQLException {
		if(connect != null) return connect;
		String url = "jdbc:mysql://localhost:3306/airticketswapper";
		String username = "root";
		String password = "root";
		
		return getConnection(url, username, password);
	}
	private static Connection getConnection(String dataname,String username,String password)
    {
    Connection conn = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
           
            conn=DriverManager.getConnection(dataname, username, password);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return conn;        
    
	
    }	


}

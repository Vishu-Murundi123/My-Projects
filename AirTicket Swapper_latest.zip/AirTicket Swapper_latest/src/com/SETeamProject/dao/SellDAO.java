package com.SETeamProject.dao;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

import com.SETeamProject.entity.SellVO;

public class SellDAO {
	
	public void regdata(SellVO sellvo) {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airticketswapper","root","root");
			Statement st1 =  conn.createStatement();
			st1.executeUpdate("INSERT INTO buy_page(source, destination, c_name, passport, conf_number, departure, arrival, class, tseats, airline, dtime, atime, price, meal, id) values('"+sellvo.getSource()+"','"+sellvo.getDestination()+"', '"+sellvo.getC_name()+"', '"+sellvo.getPassport()+"', '"+sellvo.getConf_number()+"', '"+sellvo.getDeparture()+"','"+sellvo.getArrival()+"','"+sellvo.getClasstype()+"','"+sellvo.getSeats()+"','"+sellvo.getAirline()+"','"+sellvo.getDtime()+"','"+sellvo.getAtime()+"', '"+sellvo.getPrice()+"', '"+sellvo.getMeals()+"' , '"+sellvo.getId()+"') ");
			st1.close();
			conn.close();
		}
		catch(Exception ex1)
		{
			
		ex1.printStackTrace();	
		
		}
		
	System.out.println("hi");
	
}
	
	public void regdata1(SellVO sellvo) {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airticketswapper","root","root");
			Statement st1 =  conn.createStatement();
			st1.executeUpdate("INSERT INTO buy_page(source, destination, c_name, passport, conf_number, departure, class, tseats, airline, dtime, price, meal, id) values('"+sellvo.getSource()+"','"+sellvo.getDestination()+"', '"+sellvo.getC_name()+"', '"+sellvo.getPassport()+"', '"+sellvo.getConf_number()+"', '"+sellvo.getDeparture()+"','"+sellvo.getClasstype()+"','"+sellvo.getSeats()+"','"+sellvo.getAirline()+"','"+sellvo.getDtime()+"','"+sellvo.getPrice()+"', '"+sellvo.getMeals()+"' , '"+sellvo.getId()+"') ");
			st1.close();
			conn.close();
		}
		catch(Exception ex1)
		{
			
		ex1.printStackTrace();	
		
		}
		
	System.out.println("hi2");
	
}
	public List<SellVO> history(SellVO sellvo) {
		List<SellVO> alldata=new ArrayList<SellVO>();
		try{
			
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airticketswapper","root","root");
			Statement st1 =  conn.createStatement();
			ResultSet rs=st1.executeQuery("select * from buy_page where id='"+sellvo.getId()+"' and conf_status='true'");
			while(rs.next()){
				SellVO sv=new SellVO();
				sv.setId(rs.getInt("id"));
				sv.setAirline(rs.getString("airline"));
				sv.setSource(rs.getString("source"));
				sv.setDestination(rs.getString("destination"));
				sv.setArrival(rs.getString("arrival"));
				sv.setDeparture(rs.getString("departure"));
				alldata.add(sv);
			}
			
			st1.close();
			conn.close();
		}
		catch(Exception ex1)
		{
			
		ex1.printStackTrace();	
		
		}
		
	
	return alldata;
	
}
}

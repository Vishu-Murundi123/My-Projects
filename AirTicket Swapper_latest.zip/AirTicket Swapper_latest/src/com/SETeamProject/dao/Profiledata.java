package com.SETeamProject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.SETeamProject.entity.Regdatabase;



public class Profiledata {
	

		
		public static Regdatabase getData(int id) throws SQLException  {
			
			PreparedStatement stmt  = getjdbcConnection().prepareStatement("select firstname,lastname,email,phone_no,address from registration where id = ?");
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			Regdatabase bean = new Regdatabase();
			if(rs.next()){
				bean.setFirstname(rs.getString(1));
				bean.setLastname(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setPhone_no(rs.getString(4));
				bean.setAddress(rs.getString(5));
			}
			return bean;
			
		}

		static Connection connect=null;
		private static Connection getjdbcConnection() throws SQLException {
			if(connect != null) return connect;
			String url = "jdbc:mysql://localhost:3306/airticketswapper";
			String username = "root";
			String password = "root";
			
			return getConnection(url, username, password);
		}
		private static Connection getConnection(String dataname,String username,String password)
	    {
	    Connection conn = null;
	        try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	           
	            conn=DriverManager.getConnection(dataname, username, password);
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }

	        return conn;        
	    
		
	    }	

}

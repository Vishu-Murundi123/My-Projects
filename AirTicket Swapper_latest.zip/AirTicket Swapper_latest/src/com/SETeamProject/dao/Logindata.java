package com.SETeamProject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class Logindata {
	

		
		public static int signin(String email, String password) throws SQLException  {
			
			PreparedStatement stmt  = getjdbcConnection().prepareStatement("select * from registration where email = ? and password = ?");
			stmt.setString(1, email);
			stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()){
				
				return rs.getInt(1);
			}
			
			return (int)0;
			
			
		}

		static Connection connect=null;
		private static Connection getjdbcConnection() throws SQLException {
			if(connect != null) return connect;
			String url = "jdbc:mysql://localhost:3306/airticketswapper";
			String username = "root";
			String password = "root";
			
			return getConnection(url, username, password);
		}
		private static Connection getConnection(String dataname,String username,String password)
	    {
	    Connection conn = null;
	        try
	        {
	            Class.forName("com.mysql.jdbc.Driver");
	           
	            conn=DriverManager.getConnection(dataname, username, password);
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }

	        return conn;        
	    
		
	    }	

}

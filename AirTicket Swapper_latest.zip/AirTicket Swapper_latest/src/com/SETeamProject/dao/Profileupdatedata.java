package com.SETeamProject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.SETeamProject.entity.Regdatabase;

public class Profileupdatedata {
	public static Boolean update(Regdatabase bean) throws SQLException {
		PreparedStatement stmt2 = getjdbcConnection().prepareStatement("Update registration set phone_no=?,address=? where id=?");
		stmt2.setString(1, bean.getPhone_no());
		stmt2.setString(2, bean.getAddress());
		stmt2.setInt(3, bean.getId());
		if(stmt2.executeUpdate()!=0){
			stmt2.close();
			return true;
		}
		else
			return false;
	}

	static Connection connect=null;
	private static Connection getjdbcConnection() throws SQLException {
		if(connect != null) return connect;
		String url = "jdbc:mysql://localhost:3306/airticketswapper";
		String username = "root";
		String password = "root";
		
		return getConnection(url, username, password);
	}
	private static Connection getConnection(String dataname,String username,String password)
    {
    Connection conn = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
           
            conn=DriverManager.getConnection(dataname, username, password);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return conn;        
    
	
    }	


}

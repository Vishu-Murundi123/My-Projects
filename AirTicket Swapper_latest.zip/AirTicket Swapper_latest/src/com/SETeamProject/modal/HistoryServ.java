package com.SETeamProject.modal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.SETeamProject.dao.SellDAO;
import com.SETeamProject.entity.SellVO;

/**
 * Servlet implementation class HistoryServ
 */
@WebServlet("/HistoryServlet")
public class HistoryServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HistoryServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		int id = (Integer)session.getAttribute("userid");
		
		SellVO sellvo = new SellVO();
		sellvo.setId(id);
		
		SellDAO dao=new SellDAO();
		List<SellVO> history=new ArrayList<SellVO>();
		history=dao.history(sellvo);
		session.setAttribute("history", history);
		response.sendRedirect("UserHistory.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

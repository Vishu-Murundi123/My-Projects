package com.SETeamProject.modal;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.SETeamProject.dao.Profiledata;
import com.SETeamProject.entity.Regdatabase;


/**
 * Servlet implementation class login
 */
@WebServlet("/Profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Regdatabase bean = new Regdatabase();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session= request.getSession();
		int id= (Integer)session.getAttribute("userid");
		try {
			bean= Profiledata.getData(id);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			if(bean != null){
				
			    edit(bean,request,"0").forward(request, response);
			}else{
				RequestDispatcher rd = request.getRequestDispatcher("Templete.jsp");
				out.println("Please Login First");
				rd.include(request, response);
			}
		} catch (Exception e) {
			
			System.out.println("Profile do get2"+e);
		}
	}
	
	
	protected RequestDispatcher edit(Regdatabase bean,HttpServletRequest request,String click){
		RequestDispatcher rs = request.getRequestDispatcher("UserProfile.jsp");
		request.setAttribute("fname", bean.getFirstname());
		request.setAttribute("click", click);
		request.setAttribute("lname", bean.getLastname());
		request.setAttribute("email", bean.getEmail());
		request.setAttribute("phone_no", bean.getPhone_no());
		request.setAttribute("address", bean.getAddress());
		return rs;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			edit(bean,request,"1").forward(request, response);

		
	}
	

}

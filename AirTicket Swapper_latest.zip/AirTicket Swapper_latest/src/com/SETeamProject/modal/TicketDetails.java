package com.SETeamProject.modal;
 
public class TicketDetails{
    private String departure;
    private String dtime;
    private String dep_date;
    private String arrival;
    private String atime;
    private String arr_date;
    private String cname;
    private String classtype;
    private String conf_num;
    private String price;
    private int seat;
    private String meals;
    private String airline;
     
     
    public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getMeals() {
        return meals;
    }
    public void setMeals(String meals) {
        this.meals = meals;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
     
     
    public String getDep_date() {
        return dep_date;
    }
    public void setDep_date(String dep_date) {
        this.dep_date = dep_date;
    }
    public String getArr_date() {
        return arr_date;
    }
    public void setArr_date(String arr_date) {
        this.arr_date = arr_date;
    }
    public int getSeat() {
        return seat;
    }
    public void setSeat(int seat) {
        this.seat = seat;
    }
    public String getDeparture() {
        return departure;
    }
    public void setDeparture(String departure) {
        this.departure = departure;
    }
    public String getDtime() {
        return dtime;
    }
    public void setDtime(String dtime) {
        this.dtime = dtime;
    }
    public String getArrival() {
        return arrival;
    }
    public void setArrival(String arrival) {
        this.arrival = arrival;
    }
    public String getAtime() {
        return atime;
    }
    public void setAtime(String atime) {
        this.atime = atime;
    }
    public String getCname() {
        return cname;
    }
    public void setCname(String cname) {
        this.cname = cname;
    }
    public String getClasstype() {
        return classtype;
    }
    public void setClasstype(String classtype) {
        this.classtype = classtype;
    }
    public String getConf_num() {
        return conf_num;
    }
    public void setConf_num(String conf_num) {
        this.conf_num = conf_num;
    }
    @Override
    public String toString() {
        return "TicketDetails [departure=" + departure + ", dtime=" + dtime + ", arrival=" + arrival + ", atime="
                + atime + ", cname=" + cname + ", classtype=" + classtype + ", conf_num=" + conf_num + "]";
    }
     
     
 
}
package com.SETeamProject.modal;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.SETeamProject.entity.SellVO;
import com.SETeamProject.dao.SellDAO;

/**
 * Servlet implementation class Sellserv
 */
@WebServlet("/Sellserv")
public class Sellserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sellserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("SellTick.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session= request.getSession();
		int id= (Integer)session.getAttribute("userid");
		
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String c_name = request.getParameter("c_name");
		String seats = request.getParameter("seats");
		String meals = request.getParameter("meals");
		String conf_number = request.getParameter("conf_number");
		String airline = request.getParameter("airline");
		String departure = request.getParameter("dep1");
		String dtime = request.getParameter("dep2");
		String arrival = request.getParameter("arr1");
		String atime = request.getParameter("arr2");
		String price = request.getParameter("price");
		String classtype = request.getParameter("classtype");
		String passport = request.getParameter("passport");
		String name= request.getParameter("name1");
		
		
		SellVO sellvo = new SellVO();
	    sellvo.setSource(source);
	    sellvo.setDestination(destination);
	    sellvo.setC_name(c_name);
	    sellvo.setSeats(seats);
	    sellvo.setMeals(meals);
	    sellvo.setPassport(passport);
	    sellvo.setConf_number(conf_number);
	    sellvo.setAirline(airline);
	    sellvo.setDeparture(departure);
	    sellvo.setDtime(dtime);
	    sellvo.setPrice(price);
	    sellvo.setClasstype(classtype);
	    sellvo.setId(id);
	    SellDAO dao=new SellDAO();
	    if(name.equals("round")){
		    sellvo.setArrival(arrival);
		    sellvo.setAtime(atime);
		    dao.regdata(sellvo);
	    }
	    else{
	    	dao.regdata1(sellvo);
	    }
	    response.sendRedirect("Submitted.jsp");
	}

}

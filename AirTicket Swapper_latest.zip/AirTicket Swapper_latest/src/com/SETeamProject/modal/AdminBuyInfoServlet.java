package com.SETeamProject.modal;
  
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
  
/**
 * Servlet implementation class AdminBuyInfoServlet
 */
@WebServlet("/AdminBuyInfoServlet")
public class AdminBuyInfoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
         
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminBuyInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
  
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //HttpSession session = request.getSession(); 
          
        List<BuyInfoDetails> list = new ArrayList<BuyInfoDetails>();
          
        try{
        Connection conn = BuyInfoDAO.connect();
        System.out.println("Connected");
          
		        
        PreparedStatement stmt = conn.prepareStatement("select * from  buyer_info where status=0");
        ResultSet result = stmt.executeQuery();
		              
		  
        while (result.next()) {
        	BuyInfoDetails ticket = new BuyInfoDetails();
		                
		    ticket.setTicket_no(result.getString(1));
		    ticket.setfirstname(result.getString(2));
		    ticket.setlastname(result.getString(3));
		    ticket.setDoB(result.getString(4));
		    ticket.setgender(result.getString(5));
		    ticket.setpassport(result.getString(6));
		    ticket.setmeal(result.getString(7));
		    ticket.setmealtype(result.getString(8));
		    ticket.setemail(result.getString(9));

		                
		    list.add(ticket);
		    }
		  
		    request.setAttribute("list",list);
		  
		    RequestDispatcher rd= request.getRequestDispatcher("AdminBuyInfo.jsp");
		    rd.forward(request, response);
		          
        
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
          
          
    }
  
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}
  
package com.SETeamProject.modal;
 
public class BuyInfoDetails{
    private String Ticket_no;
    private String firstname;
    private String lastname;
    private String DoB;
    private String gender;
    private String passport;
    private String meal;
    private String mealtype;
    private String email;

     
     
    public String getTicket_no() {
		return Ticket_no;
	}
	public void setTicket_no(String Ticket_no) {
		this.Ticket_no = Ticket_no;
	}
	public String getfirstname() {
        return firstname;
    }
    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getlastname() {
        return lastname;
    }
    public void setlastname(String lastname) {
        this.lastname = lastname;
    }
     
     
    public String getDoB() {
        return DoB;
    }
    public void setDoB(String DoB) {
        this.DoB = DoB;
    }
    public String getgender() {
        return gender;
    }
    public void setgender(String gender) {
        this.gender = gender;
    }
    public String getpassport() {
        return passport;
    }
    public void setpassport(String passport) {
        this.passport = passport;
    }
    public String getmeal() {
        return meal;
    }
    public void setmeal(String meal) {
        this.meal = meal;
    }
    public String getmealtype() {
        return mealtype;
    }
    public void setmealtype(String mealtype) {
        this.mealtype = mealtype;
    }
    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email = email;
    }
    @Override
    public String toString() {
        return "BuyInfoDetails [Ticket_no=" + Ticket_no + ", firstname=" + firstname + ", lastname=" + lastname + ", DoB="
                + DoB + ", gender=" + gender + ", passport=" + passport + ", meal=" + meal + "]";
    }
     
     
 
}
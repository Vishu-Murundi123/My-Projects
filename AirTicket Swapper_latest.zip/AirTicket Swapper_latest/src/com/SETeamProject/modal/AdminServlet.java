package com.SETeamProject.modal;
  
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
  
/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
         
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
  
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //HttpSession session = request.getSession(); 
          
        List<TicketDetails> list = new ArrayList<TicketDetails>();
          
        try{
        Connection conn = TicketDAO.connect();
        System.out.println("Connected");
          
		        
        PreparedStatement stmt = conn.prepareStatement("select * from  buy_page where conf_status = 'false'");
        ResultSet result = stmt.executeQuery();
		              
		  
        while (result.next()) {
        	TicketDetails ticket = new TicketDetails();
		                
		    ticket.setDeparture(result.getString("source"));
		    ticket.setArrival(result.getString("destination"));
		    ticket.setDep_date(result.getString("departure"));
		    ticket.setArr_date(result.getString("arrival"));
		    ticket.setConf_num(result.getString("conf_number"));
		    ticket.setClasstype(result.getString("class"));
		    ticket.setSeat(result.getInt("tseats"));
		    ticket.setDtime(result.getString("dtime"));
		    ticket.setAtime(result.getString("atime"));
		    ticket.setPrice(result.getString("price"));
		    ticket.setMeals(result.getString("meal"));
		                
		    list.add(ticket);
		    }
		  
		    request.setAttribute("list",list);
		  
		    RequestDispatcher rd= request.getRequestDispatcher("AdminConfirm.jsp");
		    rd.forward(request, response);
		          
        
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
          
          
    }
  
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
  
}
package com.SETeamProject.modal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

public class BuyInfoDAO {
	

    public static Connection connect(){
    	Connection con = null;
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airticketswapper?zeroDateTimeBehavior=convertToNull&autoReconnect=true&useSSL=false", "root", "root");
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        
        return con;
    }
    
    public int update(String ticket){ 
    
    try{
        Connection conn = BuyInfoDAO.connect();
        System.out.println("Connected");
          
		        
        PreparedStatement stmt = conn.prepareStatement("update buyer_info set status=1 where Ticket_no=? ");
        stmt.setString(1, ticket);
        int status = stmt.executeUpdate();
        if(status>0)
        	return status;
        
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
    return -1;
    }
}

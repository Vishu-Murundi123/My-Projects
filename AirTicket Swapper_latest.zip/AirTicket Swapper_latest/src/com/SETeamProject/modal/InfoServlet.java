package com.SETeamProject.modal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InfoServlet
 */
@WebServlet("/InfoServlet")
public class InfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ticket = request.getParameter("ticket");
		String fname = request.getParameter("first");
		String lname = request.getParameter("last");
		String dob = request.getParameter("age");
		String gender = request.getParameter("gender");
		String passport = request.getParameter("passport");
		String meal = request.getParameter("meal");
		String mtype = request.getParameter("type");
		String email = request.getParameter("mail");
		
		Connection conn = TicketDAO.connect();
		int i =0;
        try {
        	PreparedStatement stmt = conn.prepareStatement("insert into buyer_info(Ticket_no,firstname,lastname,DoB,gender,passport,meal,mealtype,email) values(?,?,?,?,?,?,?,?,?)");
			stmt.setString(1, ticket);
			stmt.setString(2, fname);
	        stmt.setString(3, lname);
	        stmt.setString(4, dob);
	        stmt.setString(5, gender);
	        stmt.setString(6, passport);
	        stmt.setString(7, meal);
	        stmt.setString(8, mtype);
	        stmt.setString(9, email);
	        
	        i = stmt.executeUpdate();
	        stmt.clearBatch();
	        stmt = conn.prepareStatement("delete from buy_page where conf_number = ?");
	        		stmt.setString(1, ticket);
	        stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (i > 0) {
        	response.sendRedirect("payment.jsp");
			
        }else{
        	System.out.println("Unable o proceed");
        	/*request.setAttribute("errorMessage", "Failure in connection");
			RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);*/
        }
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

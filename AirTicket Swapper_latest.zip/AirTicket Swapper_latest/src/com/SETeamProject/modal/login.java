package com.SETeamProject.modal;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.SETeamProject.service.Loginlogic;


/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("page.jsp");
		HttpSession session=request.getSession(false);
		session.invalidate();
		response.sendRedirect("Templete.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String Password = request.getParameter("password");
	
		try {
		int info = Loginlogic.logvalid(email,Password);
			if(info != 0){
				HttpSession session=request.getSession();
				session.setAttribute("userid", info);
				RequestDispatcher rs = request.getRequestDispatcher("page.jsp");
			    rs.include(request, response);
			}
			else if(email.contentEquals("admin@gmail.com") && Password.contentEquals("admin"))
			{
				response.sendRedirect("AdminPage.jsp");
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("Templete.jsp");
				out.println("emailid or password is wrong");
				rd.include(request, response);
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
	

}

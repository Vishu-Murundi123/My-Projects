package com.SETeamProject.modal;
 
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * Servlet implementation class BuyerServlet
 */
@WebServlet("/BuyerServlet")
public class BuyerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
        
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
 
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //HttpSession session = request.getSession(); 
         
        String depart = request.getParameter("depart");
        String dtime = request.getParameter("dep_time");
        String arrive = request.getParameter("arrive");
        String atime = request.getParameter("arr_time");
        String name = request.getParameter("name1");
        String classtype = request.getParameter("class");
        int adult = Integer.parseInt(request.getParameter("adult"));
        int child = Integer.parseInt(request.getParameter("child"));
        int total = adult + child;
        List<TicketDetails> list = new ArrayList<TicketDetails>();
         
        try{
        Connection conn = TicketDAO.connect();
        System.out.println("Connected");
         
        if(name.equals("oneway")){
            PreparedStatement stmt = conn.prepareStatement("select * from  buy_page where source=? and destination=? and tseats=? and class=? and departure=?");
            stmt.setString(1, depart);
            stmt.setString(2, arrive);
            stmt.setInt(3, total);
            stmt.setString(4, classtype);
            stmt.setString(5, dtime);
            ResultSet result = stmt.executeQuery();
             
 
            while(result.next()) {
                TicketDetails ticket = new TicketDetails();
                 
                ticket.setDeparture(result.getString("source"));
                ticket.setArrival(result.getString("destination"));
                ticket.setDep_date(result.getString("departure"));
                ticket.setClasstype(result.getString("class"));
                ticket.setSeat(result.getInt("tseats"));
                ticket.setDtime(result.getString("dtime"));
                ticket.setConf_num(result.getString("conf_number"));
                ticket.setAtime(result.getString("atime"));
                ticket.setPrice(result.getString("price"));
                ticket.setMeals(result.getString("meal"));
                ticket.setAirline(result.getString("airline"));
                 
                list.add(ticket);
            }
            System.out.println(list);
            request.setAttribute("list",list);
 
            RequestDispatcher rd= request.getRequestDispatcher("FlightDetails.jsp");
            rd.forward(request, response);
         
        }else if(name.equals("round")){
        	PreparedStatement stmt1 = conn.prepareStatement("select * from buy_page where source in (?, ?) and destination in (?,?) and departure in (?, ?) and arrival in (?,?) and class=?");
            stmt1.setString(1, depart);
            stmt1.setString(2, arrive);
            stmt1.setString(3, depart);
            stmt1.setString(4, arrive);
            stmt1.setString(5, dtime);
            stmt1.setString(6, atime);
            stmt1.setString(7, atime);
            stmt1.setString(8, "0000-00-00");
            stmt1.setString(9, classtype);
            
            ResultSet results = stmt1.executeQuery();
            
            while(results.next()) {
                TicketDetails ticket = new TicketDetails();
                 
                ticket.setDeparture(results.getString("source"));
                ticket.setArrival(results.getString("destination"));
                ticket.setDep_date(results.getString("departure"));
                ticket.setClasstype(results.getString("class"));
                ticket.setSeat(results.getInt("tseats"));
                ticket.setDtime(results.getString("dtime"));
                ticket.setArr_date(results.getString("arrival"));
                ticket.setConf_num(results.getString("conf_number"));
                ticket.setAtime(results.getString("atime"));
                ticket.setPrice(results.getString("price"));
                ticket.setMeals(results.getString("meal"));
                ticket.setAirline(results.getString("airline"));
                
                System.out.println(results.getString(1));
                System.out.println(ticket.toString()); 
                list.add(ticket);
            }
            
            request.setAttribute("list",list);
            System.out.println(list);
            
            RequestDispatcher rd= request.getRequestDispatcher("FlightDetails.jsp");
            rd.forward(request, response);
        }
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
         
         
    }
 
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
 
}
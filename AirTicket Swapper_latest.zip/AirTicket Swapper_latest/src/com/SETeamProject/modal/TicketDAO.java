package com.SETeamProject.modal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TicketDAO {
	

    public static Connection connect(){
    	Connection con = null;
        try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airticketswapper?zeroDateTimeBehavior=convertToNull&autoReconnect=true&useSSL=false", "root", "root");
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        
        return con;
    }
    
   /* public ArrayList<String> getRI() throws SQLException {
    * airticketswapper
        ArrayList<String> RIList = new ArrayList<String>();
        String tryquery = "select source from buy_page";
        Statement stmt2 = con.createStatement();
        ResultSet rs1 = stmt2.executeQuery(tryquery);

        while (rs1.next()) {

            RIList.add(rs1.getString("source"));

        }

        return RIList;
    }
    
    public ArrayList<String> getdes() throws SQLException {
        ArrayList<String> DList = new ArrayList<String>();
        String tryquery = "select destination from buy_page";
        Statement stmt1 = con.createStatement();
        ResultSet rs1 = stmt1.executeQuery(tryquery);

        while (rs1.next()) {

        	DList.add(rs1.getString("destination"));

        }

        return DList;
    }*/
}

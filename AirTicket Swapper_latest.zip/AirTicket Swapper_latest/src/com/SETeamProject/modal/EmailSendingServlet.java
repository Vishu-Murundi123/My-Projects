package com.SETeamProject.modal;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * A servlet that takes message details from user and send it as a new e-mail
 * through an SMTP server.
 *
 * @author www.codejava.net
 *
 */
@WebServlet("/EmailSendingServlet")
public class EmailSendingServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String host;
    private String port;
    private String user;
    private String pass;
 
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = "smtp.gmail.com";
        port = "587";
        user = "AirTickSwap2017@gmail.com";
        pass = "AirTickSwap518";
    }
 
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        // reads form fields
        //String recipient = request.getParameter("recipient");
        //String subject = request.getParameter("subject");
        //String content = request.getParameter("content");
    	String recipient = "AirTickSwap2017@gmail.com";
    	String subject = "A user has bought a ticket";
    	String content = "Ticket no = " + request.getParameter("ticket")+"\nFirst Name = "+request.getParameter("fname")+"\nLast Name = "+request.getParameter("lname")+""
    			+ "\nDate of Birth = "+request.getParameter("dob")+"\nGender = "+request.getParameter("gender")+"\nPassport = "+request.getParameter("pass")+""
    					+ "\nMeal = "+request.getParameter("meal")+"\nMeal Type = "+request.getParameter("mealtype")+"\nEmail = "+request.getParameter("email");
    	System.out.println(content);
        String resultMessage = "Success!!";
 
        try {
            EmailUtility.sendEmail(host, port, user, pass, recipient, subject,
                    content);
            resultMessage = "The e-mail was sent successfully";
            BuyInfoDAO buyinfo = new BuyInfoDAO();
            buyinfo.update(request.getParameter("ticket"));
        } catch (Exception ex) {
            ex.printStackTrace();
            resultMessage = "There were an error: " + ex.getMessage();
        } finally {
            //request.setAttribute("Message", resultMessage);
            getServletContext().getRequestDispatcher("/AdminBuyInfoServlet").forward( request, response);
        }
    }
}
package com.SETeamProject.modal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Connection connection;
		 
		 ArrayList<String> Dblist = new ArrayList<String>();
		 ArrayList<String> list = new ArrayList<String>();
         String tryquery = "select source, destination from buy_page group by source, destination";
         
		try {
			connection = TicketDAO.connect();
			Statement stmt2;
			stmt2 = connection.createStatement();
			ResultSet rs1 = stmt2.executeQuery(tryquery);
			 
			 while (rs1.next()) {
				 Dblist.add(rs1.getString(1));
				 list.add(rs1.getString(2));	 
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		 request.setAttribute("result", Dblist);
		 request.setAttribute("res", list);
         //System.out.println(Dblist);
         //System.out.println(request.getAttribute("result"));
         //System.out.println(list);
         
        /* RequestDispatcher rq = request.getRequestDispatcher("/Buy_Page.jsp");
         rq.forward(request, response);*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

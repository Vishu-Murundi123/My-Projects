Run all the python file separately in the any preferred IDE.


Execution in command line
Run:python filename.py


You will get the refined data sets.